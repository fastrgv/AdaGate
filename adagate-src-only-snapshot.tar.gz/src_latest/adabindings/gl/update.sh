find . -name "*.ads" -print | xargs sed -i 's/\ 2015\ \ /\ 2016\ \ /g'


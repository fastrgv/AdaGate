
The rgba directory contains a fast and efficient
texture loader package that always sends RGBA data
to OpenGL (regardless of the source png image).

The rgb directory contains an alternative texture
loader package that uses glPixelStorei to control
the OpenGL data interpretation in RGB-mode.


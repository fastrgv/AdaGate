
# this script for GNU/Linux
# using the gnat-project file gnu.gpr
# to build AdaGate 28may16

# use this to force a complete recompilation:
if [ -d ./obj/ ]; then
	rm ./obj/*
else
	mkdir obj
fi


# this is the typical path of gnat gpl 2015 (20150428):
export PATH=/usr/gnat/bin:$PATH

export BH=$PWD
export BA=$PWD/adabindings/gl
export BB=$PWD/adabindings/sdlada
export BC=$PWD/adabindings/AdaPngLib

gprbuild gnusnd.gpr
gprbuild gnu.gpr


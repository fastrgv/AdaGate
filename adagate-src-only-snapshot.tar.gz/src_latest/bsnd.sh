
# this is the typical path of gnat gpl 2015 (20150428):
export PATH=/usr/gnat/bin:$PATH

gprbuild gnusnd.gpr



10may16

Most of these frameworks are from the normal v2.3.2 release of SFML, and from the ./extlibs/ that goes with it.

The [hidden] OpenAL framework is a pre-release version obtained from the github repository for SFML.

Note also that the static library libopenal.a under ./libs/osx/ was built from sources obtained at https://github/com/kcat/openal-soft.

Either of these compile and run well, without any warnings.
But recent trials show the intrinsic OpenAL framework seems to work Ok.

fastrgv@gmail.com



# this script for OS-X uses the
# 1-step gnat-project file osx1.gpr
# to build AdaGate 9jun16

# use this to force a complete recompilation:
 if [ -d ./obj/ ]; then
  	rm ./obj/*
 else
  	mkdir obj
 fi


# these first 5 set the include dirs:
export BH=$PWD
export BI=$PWD/incLocal
export BA=$PWD/adabindings/gl
export BB=$PWD/adabindings/sdlada
export BC=$PWD/adabindings/AdaPngLib

# this is used for linker directory:
export BF=$PWD/adagate.app/Contents/Frameworks/

# this is used to set the system directory:
export BS=/System/Library/Frameworks/


gprbuild osx1.gpr


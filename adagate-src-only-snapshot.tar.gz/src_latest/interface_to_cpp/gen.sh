g++ -c -fdump-ada-spec -C snd4ada.hpp


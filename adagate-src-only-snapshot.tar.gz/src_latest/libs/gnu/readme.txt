
libopenal.a
...was downloaded from:

https://github.com/kcat/openal-soft

and built from source...
...this is v1.17.3...and works well 


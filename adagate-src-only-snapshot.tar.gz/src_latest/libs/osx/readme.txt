
libopenal.a
...was downloaded from:

https://github.com/kcat/openal-soft

...this is v1.17.3...and works well on OS-X
with NO deprecation notice


...requires the AudioToolBox framework


The OpenAL framework that is intrinsic to recent versions
of OS-X does not give deprecation warnings, but it also
seg.faults with RufasGate C++ code.  Yet, strangely
it works fine with AdaGate Ada code.

